import requests
from bs4 import BeautifulSoup
from app.models import Video, db
import time

BASE_URL = "https://onejav.com"


def fetch_list(page=1):
    url = f"{BASE_URL}/page/{page}/"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    return [a["href"] for a in soup.select("div.item a.box")]


def fetch_detail(url):
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    title = soup.select_one("h1").get_text(strip=True)
    code = soup.select_one("span[itemprop='alternateName']").get_text(strip=True)
    date = soup.select_one("span[itemprop='datePublished']").get_text(strip=True)
    actors = [a.get_text(strip=True) for a in soup.select("a[href*='/actresses/'])]
    magnets = [a["href"] for a in soup.select("a[href^='magnet:?'])]

    return {
        "title": title,
        "code": code,
        "date": date,
        "actors": ", ".join(actors),
        "magnets": "\n".join(magnets),
    }


def run():
    for page in range(1, 6):  # 爬取前 5 页
        print(f"[Crawler] Fetching page {page} ...")
        links = fetch_list(page)
        for link in links:
            data = fetch_detail(link)
            video = Video(
                code=data["code"],
                title=data["title"],
                actors=data["actors"],
                date=data["date"],
                magnets=data["magnets"],
            )
            db.session.add(video)
            try:
                db.session.commit()
                print(f"[Saved] {data['code']} {data['title']}")
            except Exception as e:
                db.session.rollback()
                print(f"[Error] {e}")
        time.sleep(2)
