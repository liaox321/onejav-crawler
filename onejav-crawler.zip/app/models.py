from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Video(db.Model):
    __tablename__ = "videos"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(255))
    actors = db.Column(db.String(255))
    date = db.Column(db.String(50))
    magnets = db.Column(db.Text)

    def __repr__(self):
        return f"<Video {self.code}>"
